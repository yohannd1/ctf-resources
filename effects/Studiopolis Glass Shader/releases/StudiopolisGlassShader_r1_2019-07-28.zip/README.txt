Using this effect is really simple. Start by placing the StudiopolisGlass.fx and .xml files wherever you installed Fusion.

For people that bought it from the Clickteam website, you can find it here. (C:\Program Files\Clickteam Fusion\Effects)

For people that bought it through Steam, you can find it here. (C:\Program Files\Steam\steamapps\common\Clickteam Fusion\Effects)

After placing the files into the folder, simply boot up Fusion and apply the effect to your Active.
You'll need to specifiy a texture for the Glass to use, what color your background is, (Hot Pink is recommended),
and what color you want the shadows to be. There's also an option to use Sonic Mania's color choice.

To create a background for the Glass, simply create an Active, make it the size of your Glass texture, and fill it with your desired
color. Then simply place them on top of each other, run the game, and enjoy as the shader goes to work!

Happy Developing! ~ EX64 (Shadow Rift)