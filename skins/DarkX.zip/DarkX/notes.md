# Terms
- **EE**: Event Editor
- **EL**: Event List
- **STB**: Storyboard

# Files
- ``EE_Blob.png``: The dot that appears on the start of conditions.